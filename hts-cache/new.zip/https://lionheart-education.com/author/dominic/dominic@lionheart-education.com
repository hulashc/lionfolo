<!DOCTYPE html>
<html lang="en-GB">
    <head>
        <meta charset="UTF-8">
<script type="text/javascript">
/* <![CDATA[ */
var gform;gform||(document.addEventListener("gform_main_scripts_loaded",function(){gform.scriptsLoaded=!0}),document.addEventListener("gform/theme/scripts_loaded",function(){gform.themeScriptsLoaded=!0}),window.addEventListener("DOMContentLoaded",function(){gform.domLoaded=!0}),gform={domLoaded:!1,scriptsLoaded:!1,themeScriptsLoaded:!1,isFormEditor:()=>"function"==typeof InitializeEditor,callIfLoaded:function(o){return!(!gform.domLoaded||!gform.scriptsLoaded||!gform.themeScriptsLoaded&&!gform.isFormEditor()||(gform.isFormEditor()&&console.warn("The use of gform.initializeOnLoaded() is deprecated in the form editor context and will be removed in Gravity Forms 3.1."),o(),0))},initializeOnLoaded:function(o){gform.callIfLoaded(o)||(document.addEventListener("gform_main_scripts_loaded",()=>{gform.scriptsLoaded=!0,gform.callIfLoaded(o)}),document.addEventListener("gform/theme/scripts_loaded",()=>{gform.themeScriptsLoaded=!0,gform.callIfLoaded(o)}),window.addEventListener("DOMContentLoaded",()=>{gform.domLoaded=!0,gform.callIfLoaded(o)}))},hooks:{action:{},filter:{}},addAction:function(o,r,e,t){gform.addHook("action",o,r,e,t)},addFilter:function(o,r,e,t){gform.addHook("filter",o,r,e,t)},doAction:function(o){gform.doHook("action",o,arguments)},applyFilters:function(o){return gform.doHook("filter",o,arguments)},removeAction:function(o,r){gform.removeHook("action",o,r)},removeFilter:function(o,r,e){gform.removeHook("filter",o,r,e)},addHook:function(o,r,e,t,n){null==gform.hooks[o][r]&&(gform.hooks[o][r]=[]);var d=gform.hooks[o][r];null==n&&(n=r+"_"+d.length),gform.hooks[o][r].push({tag:n,callable:e,priority:t=null==t?10:t})},doHook:function(r,o,e){var t;if(e=Array.prototype.slice.call(e,1),null!=gform.hooks[r][o]&&((o=gform.hooks[r][o]).sort(function(o,r){return o.priority-r.priority}),o.forEach(function(o){"function"!=typeof(t=o.callable)&&(t=window[t]),"action"==r?t.apply(null,e):e[0]=t.apply(null,e)})),"filter"==r)return e[0]},removeHook:function(o,r,t,n){var e;null!=gform.hooks[o][r]&&(e=(e=gform.hooks[o][r]).filter(function(o,r,e){return!!(null!=n&&n!=o.tag||null!=t&&t!=o.priority)}),gform.hooks[o][r]=e)}});
/* ]]> */
</script>

        <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">

        <meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v26.8 - https://yoast.com/product/yoast-seo-wordpress/ -->
	<title>Page not found | Lionheart Education</title><link rel="preload" href="https://lionheart-education.com/wp-content/cache/perfmatters/lionheart-education.com/css/404.used.css?ver=1765273838" as="style" /><link rel="stylesheet" id="perfmatters-used-css" href="https://lionheart-education.com/wp-content/cache/perfmatters/lionheart-education.com/css/404.used.css?ver=1765273838" media="all" />
	<meta property="og:locale" content="en_GB" />
	<meta property="og:title" content="Page not found | Lionheart Education" />
	<meta property="og:site_name" content="Lionheart Education" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://lionheart-education.com/#website","url":"https://lionheart-education.com/","name":"Lionheart Education","description":"","publisher":{"@id":"https://lionheart-education.com/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://lionheart-education.com/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-GB"},{"@type":"Organization","@id":"https://lionheart-education.com/#organization","name":"Lionheart Education","url":"https://lionheart-education.com/","logo":{"@type":"ImageObject","inLanguage":"en-GB","@id":"https://lionheart-education.com/#/schema/logo/image/","url":"https://lionheart-education.com/wp-content/uploads/2025/08/Lionheart_Schema-Logo-scaled.png","contentUrl":"https://lionheart-education.com/wp-content/uploads/2025/08/Lionheart_Schema-Logo-scaled.png","width":2560,"height":2560,"caption":"Lionheart Education"},"image":{"@id":"https://lionheart-education.com/#/schema/logo/image/"},"sameAs":["https://www.facebook.com/lionhearteducation","https://x.com/lionhearteducat","https://uk.linkedin.com/company/lionheart-education","https://www.instagram.com/lionheart.education/"]}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//use.typekit.net' />
<style id='wp-img-auto-sizes-contain-inline-css' type='text/css'>
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>
<link rel="stylesheet" id="wp-block-library-css" type="text/css" media="all" data-pmdelayedstyle="https://lionheart-education.com/wp-includes/css/dist/block-library/style.min.css">
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>
<link rel="stylesheet" id="wpa-css-css" type="text/css" media="all" data-pmdelayedstyle="https://lionheart-education.com/wp-content/plugins/honeypot/includes/css/wpa.css?ver=2.3.04">
<link rel="stylesheet" id="toc-screen-css" type="text/css" media="all" data-pmdelayedstyle="https://lionheart-education.com/wp-content/plugins/table-of-contents-plus/screen.min.css?ver=2411.1">
<style id='toc-screen-inline-css' type='text/css'>
div#toc_container {width: 100%;}
/*# sourceURL=toc-screen-inline-css */
</style>
<link rel='stylesheet' id='typekit-fonts-css' href='https://use.typekit.net/ucv6hhc.css' type='text/css' media='all' />
<link rel='stylesheet' id='lionheart-css' href='https://lionheart-education.com/wp-content/themes/lionheart/dist/css/app.min.css?ver=1764940445' type='text/css' media='all' />
<script type="text/javascript" src="https://lionheart-education.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
    <script type="pmdelayedscript" data-perfmatters-type="text/javascript" data-cfasync="false" data-no-optimize="1" data-no-defer="1" data-no-minify="1">
        /* <![CDATA[ */
        const SlateAjax = {
            "ajaxAdminUrl": "https://lionheart-education.com/wp-admin/admin-ajax.php",
            "postId": "792",
        };
        /* ]]> */
    </script>
    <link rel="icon" href="https://lionheart-education.com/wp-content/uploads/2025/08/cropped-Lionheart_Favicon-150x150.png" sizes="32x32" />
<link rel="icon" href="https://lionheart-education.com/wp-content/uploads/2025/08/cropped-Lionheart_Favicon-300x300.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://lionheart-education.com/wp-content/uploads/2025/08/cropped-Lionheart_Favicon-300x300.png" />
<meta name="msapplication-TileImage" content="https://lionheart-education.com/wp-content/uploads/2025/08/cropped-Lionheart_Favicon-300x300.png" />

        <link rel="preconnect" href="https://use.typekit.net" crossorigin>
<link rel="preconnect" href="https://p.typekit.net" crossorigin>        
        <!-- Google Tag Manager -->
<script type="pmdelayedscript" data-cfasync="false" data-no-optimize="1" data-no-defer="1" data-no-minify="1">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MLNVNZ3R');</script>
<!-- End Google Tag Manager -->

<!-- Start cookieyes banner --> <script id="cookieyes" type="pmdelayedscript" src="https://cdn-cookieyes.com/client_data/6af19854bf09c3d3863ad5e1/script.js" data-perfmatters-type="text/javascript" data-cfasync="false" data-no-optimize="1" data-no-defer="1" data-no-minify="1"></script> <!-- End cookieyes banner -->

<!-- Google tag (gtag.js) -->
<script src="https://www.googletagmanager.com/gtag/js?id=G-ZTYWNE9LK3" type="pmdelayedscript" data-cfasync="false" data-no-optimize="1" data-no-defer="1" data-no-minify="1"></script>
<script type="pmdelayedscript" data-cfasync="false" data-no-optimize="1" data-no-defer="1" data-no-minify="1">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ZTYWNE9LK3');
</script>            </head>
    <body class="error404 wp-theme-lionheart no-touch no-js">
        <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MLNVNZ3R"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->        
        <div class="page-wrap">
            
            <nav class='main-menu' data-menu='main' data-lenis-prevent><ul id="menu-main" class="menu"><li id="menu-item-1868" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1868"><a href="#">About Us</a><div class='sub-menu sub-menu--depth-0'><div class='sub-menu__inner'><p class="sub-menu__title" data-submenu-back><i class="sub-menu__title-back" role="button" aria-label="Back"></i>About Us</p><ul class="sub-menu__items">	<li id="menu-item-1893" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1893"><a href="#">About Lionheart</a><div class='sub-menu sub-menu--depth-1'><div class='sub-menu__inner'><p class="sub-menu__title" data-submenu-back><i class="sub-menu__title-back" role="button" aria-label="Back"></i>About Lionheart</p><ul class="sub-menu__items">		<li id="menu-item-1113" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1113"><a href="https://lionheart-education.com/about-lionheart/">Our Story</a></li>
		<li id="menu-item-1408" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1408"><a href="https://lionheart-education.com/about-lionheart/our-approach/">Our Approach</a></li>
		<li id="menu-item-1527" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1527"><a href="https://lionheart-education.com/about-lionheart/choosing-lionheart-tutors/">Our Tutors</a></li>
		<li id="menu-item-1852" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1852"><a href="https://lionheart-education.com/about-lionheart/our-team/">Our Team</a></li>
</ul></div></div></li>
	<li id="menu-item-1417" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1417"><a>Who We Serve</a><div class='sub-menu sub-menu--depth-1'><div class='sub-menu__inner'><p class="sub-menu__title" data-submenu-back><i class="sub-menu__title-back" role="button" aria-label="Back"></i>Who We Serve</p><ul class="sub-menu__items">		<li id="menu-item-1449" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1449"><a href="https://lionheart-education.com/about-lionheart/uk-families/">UK Families</a></li>
		<li id="menu-item-1462" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1462"><a href="https://lionheart-education.com/about-lionheart/international-families/">International Families</a></li>
		<li id="menu-item-1977" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1977"><a href="https://lionheart-education.com/about-lionheart/local-authorities/">Local Authorities</a></li>
		<li id="menu-item-2115" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2115"><a href="https://lionheart-education.com/about-lionheart/for-athletes-young-professionals/">Talent &#038; Sportspeople</a></li>
</ul></div></div></li>
	<li id="menu-item-1418" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1418"><a>Specialist Support For</a><div class='sub-menu sub-menu--depth-1'><div class='sub-menu__inner'><p class="sub-menu__title" data-submenu-back><i class="sub-menu__title-back" role="button" aria-label="Back"></i>Specialist Support For</p><ul class="sub-menu__items">		<li id="menu-item-1428" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1428"><a href="https://lionheart-education.com/about-lionheart/specialist-support-autism-spectrum-disorder/">Autism Spectrum Disorder</a></li>
		<li id="menu-item-1756" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1756"><a href="https://lionheart-education.com/about-lionheart/specialist-support-adhd-add/">Attention Deficit Hyperactivity Disorder</a></li>
		<li id="menu-item-1759" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1759"><a href="https://lionheart-education.com/about-lionheart/specialist-support-behavioural-issues/">Behavioural Issues</a></li>
		<li id="menu-item-1562" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1562"><a href="https://lionheart-education.com/about-lionheart/specialist-support-ehcp/">Education &#038; Healthcare Plans</a></li>
		<li id="menu-item-1896" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1896"><a href="https://lionheart-education.com/about-lionheart/specialist-support-mental-health-disorders/">Mental Health Disorders</a></li>
		<li id="menu-item-1439" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1439"><a href="https://lionheart-education.com/about-lionheart/special-educational-needs-disabilities/">Special Educational Needs</a></li>
		<li id="menu-item-1760" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1760"><a href="https://lionheart-education.com/about-lionheart/specialist-support-school-exclusion/">School Exclusion</a></li>
</ul></div></div></li>
	<li id="menu-item-1990" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1990"><a href="https://lionheart-education.com/about-lionheart/our-team/">Our Team</a></li>
</ul></div></div></li>
<li id="menu-item-1869" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1869"><a href="#">Consultancy</a><div class='sub-menu sub-menu--depth-0'><div class='sub-menu__inner'><p class="sub-menu__title" data-submenu-back><i class="sub-menu__title-back" role="button" aria-label="Back"></i>Consultancy</p><ul class="sub-menu__items">	<li id="menu-item-1490" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1490"><a href="https://lionheart-education.com/consultancy-with-lionheart/">Consultancy with Lionheart</a></li>
	<li id="menu-item-1899" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1899"><a href="#">Admissions</a><div class='sub-menu sub-menu--depth-1'><div class='sub-menu__inner'><p class="sub-menu__title" data-submenu-back><i class="sub-menu__title-back" role="button" aria-label="Back"></i>Admissions</p><ul class="sub-menu__items">		<li id="menu-item-1641" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1641"><a href="https://lionheart-education.com/consultancy-with-lionheart/early-years-nursery-admissions/">Early Years &#038; Nurseries</a></li>
		<li id="menu-item-1503" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1503"><a href="https://lionheart-education.com/consultancy-with-lionheart/school-placement/">School Placement</a></li>
		<li id="menu-item-1517" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1517"><a href="https://lionheart-education.com/consultancy-with-lionheart/university-admissions/">University Admissions</a></li>
</ul></div></div></li>
	<li id="menu-item-1900" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1900"><a href="#">Specialist Support</a><div class='sub-menu sub-menu--depth-1'><div class='sub-menu__inner'><p class="sub-menu__title" data-submenu-back><i class="sub-menu__title-back" role="button" aria-label="Back"></i>Specialist Support</p><ul class="sub-menu__items">		<li id="menu-item-1879" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1879"><a href="https://lionheart-education.com/consultancy-with-lionheart/mental-health/">Mental Health</a></li>
		<li id="menu-item-1878" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1878"><a href="https://lionheart-education.com/consultancy-with-lionheart/special-educational-needs-and-disabilities-send/">SEND</a></li>
		<li id="menu-item-1521" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1521"><a href="https://lionheart-education.com/consultancy-with-lionheart/education-crisis-management/">Education Crisis Management</a></li>
</ul></div></div></li>
	<li id="menu-item-1553" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1553"><a href="https://lionheart-education.com/consultancy-with-lionheart/relocation-support/">Relocation Support</a></li>
</ul></div></div></li>
<li id="menu-item-1870" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1870"><a href="#">Lionheart School</a><div class='sub-menu sub-menu--depth-0'><div class='sub-menu__inner'><p class="sub-menu__title" data-submenu-back><i class="sub-menu__title-back" role="button" aria-label="Back"></i>Lionheart School</p><ul class="sub-menu__items">	<li id="menu-item-1115" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1115"><a href="https://lionheart-education.com/lionheart-school/">About the School</a></li>
	<li id="menu-item-1035" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1035"><a href="https://lionheart-education.com/lionheart-school/school-life-a-typical-day/">School Life &#038; Approach</a></li>
	<li id="menu-item-2030" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2030"><a href="https://lionheart-education.com/lionheart-school/alternative-provision/">Alternative Provision</a></li>
	<li id="menu-item-1293" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1293"><a href="https://lionheart-education.com/lionheart-school/admissions/">Admissions</a></li>
	<li id="menu-item-2060" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2060"><a href="https://lionheart-education.com/lionheart-school/examination-centre/">Examination Centre</a></li>
	<li id="menu-item-2034" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2034"><a href="https://lionheart-education.com/lionheart-school/term-dates/">Term Dates</a></li>
</ul></div></div></li>
<li id="menu-item-1871" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1871"><a href="#">Homeschooling</a><div class='sub-menu sub-menu--depth-0'><div class='sub-menu__inner'><p class="sub-menu__title" data-submenu-back><i class="sub-menu__title-back" role="button" aria-label="Back"></i>Homeschooling</p><ul class="sub-menu__items">	<li id="menu-item-1118" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1118"><a href="https://lionheart-education.com/homeschooling/">Homeschooling Specialists</a></li>
	<li id="menu-item-2061" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2061"><a href="https://lionheart-education.com/lionheart-school/examination-centre/">Examination Centre</a></li>
</ul></div></div></li>
<li id="menu-item-1872" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1872"><a href="#">Private Tuition</a><div class='sub-menu sub-menu--depth-0'><div class='sub-menu__inner'><p class="sub-menu__title" data-submenu-back><i class="sub-menu__title-back" role="button" aria-label="Back"></i>Private Tuition</p><ul class="sub-menu__items">	<li id="menu-item-1116" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1116"><a href="https://lionheart-education.com/private-tuition/">Overview</a></li>
	<li id="menu-item-1334" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1334"><a>Early Years &#038; Primary</a><div class='sub-menu sub-menu--depth-1'><div class='sub-menu__inner'><p class="sub-menu__title" data-submenu-back><i class="sub-menu__title-back" role="button" aria-label="Back"></i>Early Years & Primary</p><ul class="sub-menu__items">		<li id="menu-item-1333" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1333"><a href="https://lionheart-education.com/private-tuition/early-years-nursery/">Early Years &#038; Nursery</a></li>
		<li id="menu-item-1389" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1389"><a href="https://lionheart-education.com/private-tuition/primary-tuition/">Year 1 – Year 6</a></li>
</ul></div></div></li>
	<li id="menu-item-1329" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1329"><a>Secondary</a><div class='sub-menu sub-menu--depth-1'><div class='sub-menu__inner'><p class="sub-menu__title" data-submenu-back><i class="sub-menu__title-back" role="button" aria-label="Back"></i>Secondary</p><ul class="sub-menu__items">		<li id="menu-item-1707" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1707"><a href="https://lionheart-education.com/private-tuition/gcse-igcse/">GCSE &#038; IGCSE</a></li>
		<li id="menu-item-1331" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1331"><a href="https://lionheart-education.com/private-tuition/a-level/">A-Level</a></li>
		<li id="menu-item-1330" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1330"><a href="https://lionheart-education.com/private-tuition/international-baccalaureate-ib/">IB (International Baccalaureate)</a></li>
</ul></div></div></li>
	<li id="menu-item-1873" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1873"><a href="#">School Entrance Preparation</a><div class='sub-menu sub-menu--depth-1'><div class='sub-menu__inner'><p class="sub-menu__title" data-submenu-back><i class="sub-menu__title-back" role="button" aria-label="Back"></i>School Entrance Preparation</p><ul class="sub-menu__items">		<li id="menu-item-1055" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1055"><a href="https://lionheart-education.com/private-tuition/7-plus-tuition/">7+</a></li>
		<li id="menu-item-1336" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1336"><a href="https://lionheart-education.com/private-tuition/8-plus-tuition/">8+</a></li>
		<li id="menu-item-1273" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1273"><a href="https://lionheart-education.com/private-tuition/11-plus-tuition/">11+</a></li>
		<li id="menu-item-1274" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1274"><a href="https://lionheart-education.com/private-tuition/13-plus-common-entrance-tuition/">13+ Common Entrance</a></li>
		<li id="menu-item-1275" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1275"><a href="https://lionheart-education.com/private-tuition/16-plus-tuition/">16+</a></li>
</ul></div></div></li>
	<li id="menu-item-1874" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1874"><a href="#">Oxbridge &#038; University Entrance</a><div class='sub-menu sub-menu--depth-1'><div class='sub-menu__inner'><p class="sub-menu__title" data-submenu-back><i class="sub-menu__title-back" role="button" aria-label="Back"></i>Oxbridge & University Entrance</p><ul class="sub-menu__items">		<li id="menu-item-1359" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1359"><a href="https://lionheart-education.com/private-tuition/oxbridge-admissions-tuition/">Oxbridge Tuition</a></li>
		<li id="menu-item-1375" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1375"><a href="https://lionheart-education.com/private-tuition/lnat-law-national-aptitude-test/">LNAT Tuition</a></li>
		<li id="menu-item-1373" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1373"><a href="https://lionheart-education.com/private-tuition/sat-scholastic-assessment-test/">SAT Tuition</a></li>
		<li id="menu-item-1372" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1372"><a href="https://lionheart-education.com/private-tuition/act-american-college-testing/">ACT Tuition</a></li>
		<li id="menu-item-1732" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1732"><a href="https://lionheart-education.com/private-tuition/ap-advanced-placement/">AP Tuition</a></li>
		<li id="menu-item-1374" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1374"><a href="https://lionheart-education.com/private-tuition/ucat-university-clinical-aptitude-test/">UCAT Tuition</a></li>
		<li id="menu-item-1840" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1840"><a href="https://lionheart-education.com/private-tuition/gmat-graduate-management-admission-test/">GMAT Tuition</a></li>
</ul></div></div></li>
	<li id="menu-item-1327" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1327"><a href="https://lionheart-education.com/private-tuition/international-travelling-tutors/">International &#038; Travelling Tutors</a></li>
</ul></div></div></li>
<li id="menu-item-902" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-902"><a href="https://lionheart-education.com/courses/">Bespoke Courses</a></li>
<li id="menu-item-903" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-903"><a href="https://lionheart-education.com/lionheart-blog/">The Knowledge Hub</a></li>
<li id="menu-item-1058" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1058"><a href="https://lionheart-education.com/contact/">Contact Us</a></li>
    <li class="menu-item menu-item--btn bg-colorway-black">
        <span><a href='#popover-start-your-journey' class='btn--full btn btn--regular'    role="button"><span class="btn__txt"><span class="btn__txt-inner" data-txt="Start your journey">Start your journey</span></span></a></span>
    </li></ul></nav><section class="overlay-modal" data-modal="search" data-lenis-prevent>
    <div class="overlay-modal__inner section section--large bg-colorway-black pv-small">
        <header class="overlay-modal__header">
            <form method="get" class="search-form" action="https://lionheart-education.com/" data-search>
    <input type="text" class="search-form__field" placeholder="Search" value="" name="s">
</form>
        </header>

        <div class="overlay-modal__content">
            <div id="search-results"></div>
        </div>
    </div>
</section>

<header class="header">
    
    <div class="header__inner">
        <div class="header__icons">
                                                <i class="header__icon header__icon--menu" role="button" aria-label="Menu" data-menu-target="main"></i>
                
                <i class="header__icon header__icon--search" role="button" aria-label="Search" data-modal-target="search"></i>
                    </div>

        <div class="header__logo">
                            <a href="https://lionheart-education.com" class="header__logo-link">
                    Lionheart                </a>
                    </div>

        <div class="header__btn">
            <a href='#popover-start-your-journey' class='btn--small btn'    role="button"><span class="btn__txt"><span class="btn__txt-inner" data-txt="Start your journey">Start your journey</span></span></a>        </div>
    </div>

    </header>

            
<section id="banner-1" class="section-image-banner bg-colorway-beige">
    <div class="img-banner">
                    <div class="img-banner__img">
                <picture>
                    <source srcset="https://lionheart-education.com/wp-content/uploads/2025/07/img-1-669x815.webp" media="(max-width: 669px)">
                        <img
        
        class="img-full"
        width='1280' height='1600'
        src='https://lionheart-education.com/wp-content/uploads/2025/07/img-1-1280x1600.webp'
        
        alt=''>                </picture>

                            </div>
        
                    <div class="img-banner__txt content">
                <h1><span class="txt-script">Error 404</span></h1>
<hr />
<h2><span class="h1">You must be lost…</span></h2>
<p>Let&#8217;s get you back on track</p>
<a href='/' class='btn--outline btn btn--regular'   ><span class="btn__txt"><span class="btn__txt-inner" data-txt="Head for home">Head for home</span></span></a>
            </div>
            </div>
</section>
            
            
<section id="footer-1" class="section-call-to-action bg-colorway-beige">
    <div class="cta">
        <div class="cta__inner section section--large pv-small">
            
            <div class="cta__content">
                                    <div class="cta__txt content">
                        <p><span class="h5">For the latest from Lionheart, sign up to our newsletter.</span></p>
                    </div>
                
                                    <div class="cta__form">
                        
<div class="form-wrapper"  data-popover-on-submit="start-your-journey">
    
                <div class='gf_browser_gecko gform_wrapper gravity-theme gform-theme--no-framework gform-inline_wrapper' data-form-theme='gravity-theme' data-form-index='0' id='gform_wrapper_3' ><form method='post' enctype='multipart/form-data' target='gform_ajax_frame_3' id='gform_3' class='gform-inline' action='/author/dominic/dominic@lionheart-education.com' data-formid='3' novalidate>
                        <div class='gform-body gform_body'><div id='gform_fields_3' class='gform_fields top_label form_sublabel_below description_below validation_below'><div id="field_3_1" class="gfield gfield--type-email gfield--input-type-email gfield_contains_required field_sublabel_below gfield--no-description field_description_below field_validation_below gfield_visibility_visible"  ><label class='gfield_label gform-field-label' for='input_3_1'>Enter email<span class="gfield_required"><span class="gfield_required gfield_required_text">(Required)</span></span></label><div class='ginput_container ginput_container_email'>
                            <input name='input_1' id='input_3_1' type='email' value='' class='large'    aria-required="true" aria-invalid="false"  />
                        </div></div></div></div>
        <div class='gform-footer gform_footer top_label'> <button class='gform_button btn btn--regular' id='gform_submit_button_3' data-gf-id='3' aria-label='Sign Up'><span class='btn__txt'><span class='btn__txt-inner' data-txt='Sign Up'>Sign Up</span></span></button> <input type='hidden' name='gform_ajax' value='form_id=3&amp;title=&amp;description=&amp;tabindex=0&amp;theme=gravity-theme&amp;styles=[]&amp;hash=ebba08b25630e0596f62b890918e5c32' />
            <input type='hidden' class='gform_hidden' name='gform_submission_method' data-js='gform_submission_method_3' value='iframe' />
            <input type='hidden' class='gform_hidden' name='gform_theme' data-js='gform_theme_3' id='gform_theme_3' value='gravity-theme' />
            <input type='hidden' class='gform_hidden' name='gform_style_settings' data-js='gform_style_settings_3' id='gform_style_settings_3' value='[]' />
            <input type='hidden' class='gform_hidden' name='is_submit_3' value='1' />
            <input type='hidden' class='gform_hidden' name='gform_submit' value='3' />
            
            <input type='hidden' class='gform_hidden' name='gform_currency' data-currency='GBP' value='bQS0YWu3/2Mx163odMhYcXpSHp+9PUxALH7aUZBNNiF7LHBrAUbzsMFQfHxXVvs33zGYUdp3jT/WszGWaMU+j/da8a8H+mvsw7gRXPjNeOHU9Oo=' />
            <input type='hidden' class='gform_hidden' name='gform_unique_id' value='' />
            <input type='hidden' class='gform_hidden' name='state_3' value='WyJbXSIsIjlkMjZjMjMyYTNiMDc4MDg2MGUxNGE4NzMwZTVjNWNjIl0=' />
            <input type='hidden' autocomplete='off' class='gform_hidden' name='gform_target_page_number_3' id='gform_target_page_number_3' value='0' />
            <input type='hidden' autocomplete='off' class='gform_hidden' name='gform_source_page_number_3' id='gform_source_page_number_3' value='1' />
            <input type='hidden' name='gform_field_values' value='' />
            
        </div>
                        </form>
                        </div>
		                <iframe style='display:none;width:0px;height:0px;' src='about:blank' name='gform_ajax_frame_3' id='gform_ajax_frame_3' title='This iframe contains the logic required to handle Ajax powered Gravity Forms.'></iframe>
		                <script type="text/javascript">
/* <![CDATA[ */
 gform.initializeOnLoaded( function() {gformInitSpinner( 3, 'https://lionheart-education.com/wp-content/plugins/gravityforms/images/spinner.svg', true );jQuery('#gform_ajax_frame_3').on('load',function(){var contents = jQuery(this).contents().find('*').html();var is_postback = contents.indexOf('GF_AJAX_POSTBACK') >= 0;if(!is_postback){return;}var form_content = jQuery(this).contents().find('#gform_wrapper_3');var is_confirmation = jQuery(this).contents().find('#gform_confirmation_wrapper_3').length > 0;var is_redirect = contents.indexOf('gformRedirect(){') >= 0;var is_form = form_content.length > 0 && ! is_redirect && ! is_confirmation;var mt = parseInt(jQuery('html').css('margin-top'), 10) + parseInt(jQuery('body').css('margin-top'), 10) + 100;if(is_form){jQuery('#gform_wrapper_3').html(form_content.html());if(form_content.hasClass('gform_validation_error')){jQuery('#gform_wrapper_3').addClass('gform_validation_error');} else {jQuery('#gform_wrapper_3').removeClass('gform_validation_error');}setTimeout( function() { /* delay the scroll by 50 milliseconds to fix a bug in chrome */  }, 50 );if(window['gformInitDatepicker']) {gformInitDatepicker();}if(window['gformInitPriceFields']) {gformInitPriceFields();}var current_page = jQuery('#gform_source_page_number_3').val();gformInitSpinner( 3, 'https://lionheart-education.com/wp-content/plugins/gravityforms/images/spinner.svg', true );jQuery(document).trigger('gform_page_loaded', [3, current_page]);window['gf_submitting_3'] = false;}else if(!is_redirect){var confirmation_content = jQuery(this).contents().find('.GF_AJAX_POSTBACK').html();if(!confirmation_content){confirmation_content = contents;}jQuery('#gform_wrapper_3').replaceWith(confirmation_content);jQuery(document).trigger('gform_confirmation_loaded', [3]);window['gf_submitting_3'] = false;wp.a11y.speak(jQuery('#gform_confirmation_message_3').text());}else{jQuery('#gform_3').append(contents);if(window['gformRedirect']) {gformRedirect();}}jQuery(document).trigger("gform_pre_post_render", [{ formId: "3", currentPage: "current_page", abort: function() { this.preventDefault(); } }]);        if (event && event.defaultPrevented) {                return;        }        const gformWrapperDiv = document.getElementById( "gform_wrapper_3" );        if ( gformWrapperDiv ) {            const visibilitySpan = document.createElement( "span" );            visibilitySpan.id = "gform_visibility_test_3";            gformWrapperDiv.insertAdjacentElement( "afterend", visibilitySpan );        }        const visibilityTestDiv = document.getElementById( "gform_visibility_test_3" );        let postRenderFired = false;        function triggerPostRender() {            if ( postRenderFired ) {                return;            }            postRenderFired = true;            gform.core.triggerPostRenderEvents( 3, current_page );            if ( visibilityTestDiv ) {                visibilityTestDiv.parentNode.removeChild( visibilityTestDiv );            }        }        function debounce( func, wait, immediate ) {            var timeout;            return function() {                var context = this, args = arguments;                var later = function() {                    timeout = null;                    if ( !immediate ) func.apply( context, args );                };                var callNow = immediate && !timeout;                clearTimeout( timeout );                timeout = setTimeout( later, wait );                if ( callNow ) func.apply( context, args );            };        }        const debouncedTriggerPostRender = debounce( function() {            triggerPostRender();        }, 200 );        if ( visibilityTestDiv && visibilityTestDiv.offsetParent === null ) {            const observer = new MutationObserver( ( mutations ) => {                mutations.forEach( ( mutation ) => {                    if ( mutation.type === 'attributes' && visibilityTestDiv.offsetParent !== null ) {                        debouncedTriggerPostRender();                        observer.disconnect();                    }                });            });            observer.observe( document.body, {                attributes: true,                childList: false,                subtree: true,                attributeFilter: [ 'style', 'class' ],            });        } else {            triggerPostRender();        }    } );} ); 
/* ]]> */
</script>
</div>
                    </div>
                            </div>
        </div>
    </div>
</section>

            
            
<footer class="footer">
    <div class="footer__section footer__section--main pv-small bg-colorway-black">
        <div class="footer__section-inner">
                            <div class="footer__btns">
                                            <a href='tel:+44 (0) 20 7602 2012' class='btn--outline btn btn--regular'   ><span class="btn__txt"><span class="btn__txt-inner" data-txt="+44 (0) 20 7602 2012">+44 (0) 20 7602 2012</span></span></a>                                            <a href='mailto:office@lionheart-education.com' class='btn--outline btn btn--regular'   ><span class="btn__txt"><span class="btn__txt-inner" data-txt="Email Us">Email Us</span></span></a>                                            <a href='https://lionheart-education.com/contact/refer-to-lionheart/' class='btn--outline btn btn--regular'   ><span class="btn__txt"><span class="btn__txt-inner" data-txt="Make a referral">Make a referral</span></span></a>                                    </div>
            
            <div class="footer__cols">
                                    <div class="footer__cols-badge">
                        <img class="footer__cols-badge-img" src="https://lionheart-education.com/wp-content/themes/lionheart/dist/img/footer-badge.svg" width="193" height="184" alt="School badge" loading="lazy">
                    </div>
                
                <div class="footer__cols-menus">
                                            <div class="footer__cols-menu">
                            <p class="footer__cols-menu-title h6" data-toggle-target="footer-menu-0" data-toggle-max="1024">
                                Services                            </p>

                            <div class="footer__cols-menu-items" data-toggle="footer-menu-0">
                                <ul id="menu-services" class="menu"><li id="menu-item-2077" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2077"><a href="https://lionheart-education.com/consultancy-with-lionheart/">Consultancy</a></li>
<li id="menu-item-1079" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1079"><a href="https://lionheart-education.com/lionheart-school/">About Lionheart School</a></li>
<li id="menu-item-1078" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1078"><a href="https://lionheart-education.com/homeschooling/">Homeschooling Specialists</a></li>
<li id="menu-item-1080" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1080"><a href="https://lionheart-education.com/private-tuition/">Expert Private Tuition</a></li>
<li id="menu-item-1077" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1077"><a href="https://lionheart-education.com/courses/">Bespoke Tuition Courses</a></li>
<li id="menu-item-2078" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2078"><a href="https://lionheart-education.com/lionheart-school/examination-centre/">Examination Centre</a></li>
</ul>                            </div>
                        </div>
                                            <div class="footer__cols-menu">
                            <p class="footer__cols-menu-title h6" data-toggle-target="footer-menu-1" data-toggle-max="1024">
                                Main                            </p>

                            <div class="footer__cols-menu-items" data-toggle="footer-menu-1">
                                <ul id="menu-main-1" class="menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1868"><a href="#">About Us</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1869"><a href="#">Consultancy</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1870"><a href="#">Lionheart School</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1871"><a href="#">Homeschooling</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1872"><a href="#">Private Tuition</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-902"><a href="https://lionheart-education.com/courses/">Bespoke Courses</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-903"><a href="https://lionheart-education.com/lionheart-blog/">The Knowledge Hub</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1058"><a href="https://lionheart-education.com/contact/">Contact Us</a></li>
</ul>                            </div>
                        </div>
                                            <div class="footer__cols-menu">
                            <p class="footer__cols-menu-title h6" data-toggle-target="footer-menu-3" data-toggle-max="1024">
                                Connect                            </p>

                            <div class="footer__cols-menu-items" data-toggle="footer-menu-3">
                                <ul id="menu-connect" class="menu"><li id="menu-item-1089" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1089"><a target="_blank" href="https://uk.linkedin.com/company/lionheart-education">Linkedin</a></li>
<li id="menu-item-1090" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1090"><a target="_blank" href="https://www.instagram.com/lionheart.education/">Instagram</a></li>
<li id="menu-item-1091" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1091"><a target="_blank" href="https://www.facebook.com/lionhearteducation">Facebook</a></li>
<li id="menu-item-1092" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1092"><a target="_blank" href="https://x.com/lionhearteducat">X</a></li>
</ul>                            </div>
                        </div>
                                    </div>
            </div>

                            <div class="footer__meta">
                                            <p class="footer__meta-disclaimer">
                            Lionheart Education is the trading name of Blythe Hall Limited.<br />
Registered office: Blythe Hall,100 Blythe Road, London, W14 0HB. Registered in England and Wales: company number 05617230.                         </p>
                    
                                            <p class="footer__meta-copyright">
                            © 2025 All rights reserved Lionheart Education
                                                            <br>
                            
                            <a href='https://www.fhoke.com' target='_blank'>Web Design by Fhoke</a>                        </p>
                                    </div>
                    </div>
    </div>

            <div class="footer__section footer__section--strapline bg-colorway-black">
            <div class="footer__section-inner">
                <p class="footer__strapline">
                    <span data-fit-txt>
                        Illegitimi non carborundum                    </span>
                </p>
            </div>
        </div>
    
            <div class="footer__section footer__section--logos pv-tiny bg-colorway-beige">
            <div class="footer__section-inner">
                <ul class="footer__logos">
                                            
                        <li class="footer__logos-item">
                                <img
        loading="lazy"
        class="img-full"
         
        src='https://lionheart-education.com/wp-content/uploads/2025/07/logo-fsb.svg'
        
        alt=''>                        </li>
                                            
                        <li class="footer__logos-item">
                            <a href='https://thetutorsassociation.org.uk/about/fellows/'    aria-label='The Tutors' Association'>    <img
        loading="lazy"
        class="img-full"
         
        src='https://lionheart-education.com/wp-content/uploads/2025/07/logo-the-tutors-association.svg'
        
        alt=''></a>                        </li>
                                            
                        <li class="footer__logos-item">
                            <a href='https://spears500.com/adviser/25703/oliver-gilsenan'    aria-label='spears_logo'>    <img width="425" height="110"
        loading="lazy"
        class="img-full"
         
        src='https://lionheart-education.com/wp-content/uploads/2026/01/spears_logo.webp'
        
        alt='Spear&#039;s 500 logo'></a>                        </li>
                                    </ul>
            </div>
        </div>
    </footer>

            <style>
</style>

<aside class="popover" data-popover="start-your-journey" id="popover-start-your-journey">
    <div class="popover__overlay" data-popover-target="start-your-journey"></div>
    
    <div class="popover__inner">
        <header class="popover__header">
                            <h2 class="popover__header-title txt-script">
                    Start Your Journey                </h2>
            
            <span class="popover__header-close" data-popover-target="start-your-journey" role="button" aria-label="Close popover"></span>
        </header>

        <div class="popover__content" data-lenis-prevent>
                            <div class="txt-small content content--small">
                    <h5>Please complete the information below and a member of our specialist team will be in touch.</h5>
                </div>
            
                            <div class="popover__form">
                    
<div class="form-wrapper" >
    <script src="https://js-eu1.hsforms.net/forms/embed/developer/143825998.js" type="pmdelayedscript" data-cfasync="false" data-no-optimize="1" data-no-defer="1" data-no-minify="1"></script>
<div class="hs-form-html" data-region="eu1" data-form-id="dfe80be2-ea58-41ae-b56d-f9052f87554d" data-portal-id="143825998"></div></div>
                </div>
                    </div>
    </div>
</aside>
        </div><!--end .page-wrap-->

        <script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/lionheart/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
<script type="text/javascript" src="https://lionheart-education.com/wp-content/plugins/honeypot/includes/js/wpa.js?ver=2.3.04" id="wpascript-js"></script>
<script type="text/javascript" id="wpascript-js-after">
/* <![CDATA[ */
wpa_field_info = {"wpa_field_name":"bakfce1479","wpa_field_value":692252,"wpa_add_test":"no"}
//# sourceURL=wpascript-js-after
/* ]]> */
</script>
<script type="pmdelayedscript" id="toc-front-js-extra" data-perfmatters-type="text/javascript" data-cfasync="false" data-no-optimize="1" data-no-defer="1" data-no-minify="1">
/* <![CDATA[ */
var tocplus = {"smooth_scroll":"1","visibility_show":"show","visibility_hide":"hide","width":"100%"};
//# sourceURL=toc-front-js-extra
/* ]]> */
</script>
<script type="pmdelayedscript" src="https://lionheart-education.com/wp-content/plugins/table-of-contents-plus/front.min.js?ver=2411.1" id="toc-front-js" data-perfmatters-type="text/javascript" data-cfasync="false" data-no-optimize="1" data-no-defer="1" data-no-minify="1"></script>
<script type="text/javascript" src="https://lionheart-education.com/wp-content/plugins/wp-armour-extended/includes/js/wpae.js?ver=2.3.04" id="wpaescript-js"></script>
<script type="text/javascript" src="https://lionheart-education.com/wp-content/themes/lionheart/dist/js/app.min.js?ver=1764167254" id="lionheart-js" defer="defer" data-wp-strategy="defer"></script>
<script type="pmdelayedscript" src="https://lionheart-education.com/wp-includes/js/dist/dom-ready.min.js?ver=f77871ff7694fffea381" id="wp-dom-ready-js" data-perfmatters-type="text/javascript" data-cfasync="false" data-no-optimize="1" data-no-defer="1" data-no-minify="1"></script>
<script type="pmdelayedscript" src="https://lionheart-education.com/wp-includes/js/dist/hooks.min.js?ver=dd5603f07f9220ed27f1" id="wp-hooks-js" data-perfmatters-type="text/javascript" data-cfasync="false" data-no-optimize="1" data-no-defer="1" data-no-minify="1"></script>
<script type="pmdelayedscript" src="https://lionheart-education.com/wp-includes/js/dist/i18n.min.js?ver=c26c3dc7bed366793375" id="wp-i18n-js" data-perfmatters-type="text/javascript" data-cfasync="false" data-no-optimize="1" data-no-defer="1" data-no-minify="1"></script>
<script type="pmdelayedscript" id="wp-i18n-js-after" data-perfmatters-type="text/javascript" data-cfasync="false" data-no-optimize="1" data-no-defer="1" data-no-minify="1">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
/* ]]> */
</script>
<script type="pmdelayedscript" id="wp-a11y-js-translations" data-perfmatters-type="text/javascript" data-cfasync="false" data-no-optimize="1" data-no-defer="1" data-no-minify="1">
/* <![CDATA[ */
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2025-11-13 00:57:08+0000","generator":"GlotPress\/4.0.3","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=2; plural=n != 1;","lang":"en_GB"},"Notifications":["Notifications"]}},"comment":{"reference":"wp-includes\/js\/dist\/a11y.js"}} );
//# sourceURL=wp-a11y-js-translations
/* ]]> */
</script>
<script type="pmdelayedscript" src="https://lionheart-education.com/wp-includes/js/dist/a11y.min.js?ver=cb460b4676c94bd228ed" id="wp-a11y-js" data-perfmatters-type="text/javascript" data-cfasync="false" data-no-optimize="1" data-no-defer="1" data-no-minify="1"></script>
<script type="text/javascript" defer='defer' src="https://lionheart-education.com/wp-content/plugins/gravityforms/js/jquery.json.min.js?ver=2.9.26" id="gform_json-js"></script>
<script type="text/javascript" id="gform_gravityforms-js-extra">
/* <![CDATA[ */
var gform_i18n = {"datepicker":{"days":{"monday":"Mo","tuesday":"Tu","wednesday":"We","thursday":"Th","friday":"Fr","saturday":"Sa","sunday":"Su"},"months":{"january":"January","february":"February","march":"March","april":"April","may":"May","june":"June","july":"July","august":"August","september":"September","october":"October","november":"November","december":"December"},"firstDay":1,"iconText":"Select date"}};
var gf_legacy_multi = [];
var gform_gravityforms = {"strings":{"invalid_file_extension":"This type of file is not allowed. Must be one of the following:","delete_file":"Delete this file","in_progress":"in progress","file_exceeds_limit":"File exceeds size limit","illegal_extension":"This type of file is not allowed.","max_reached":"Maximum number of files reached","unknown_error":"There was a problem while saving the file on the server","currently_uploading":"Please wait for the uploading to complete","cancel":"Cancel","cancel_upload":"Cancel this upload","cancelled":"Cancelled","error":"Error","message":"Message"},"vars":{"images_url":"https://lionheart-education.com/wp-content/plugins/gravityforms/images"}};
var gf_global = {"gf_currency_config":{"name":"Pound Sterling","symbol_left":"&#163;","symbol_right":"","symbol_padding":" ","thousand_separator":",","decimal_separator":".","decimals":2,"code":"GBP"},"base_url":"https://lionheart-education.com/wp-content/plugins/gravityforms","number_formats":[],"spinnerUrl":"https://lionheart-education.com/wp-content/plugins/gravityforms/images/spinner.svg","version_hash":"049c7236a7e56ca64076ab4f4695a3db","strings":{"newRowAdded":"New row added.","rowRemoved":"Row removed","formSaved":"The form has been saved.  The content contains the link to return and complete the form."}};
//# sourceURL=gform_gravityforms-js-extra
/* ]]> */
</script>
<script type="text/javascript" defer='defer' src="https://lionheart-education.com/wp-content/plugins/gravityforms/js/gravityforms.min.js?ver=2.9.26" id="gform_gravityforms-js"></script>
<script type="text/javascript" defer='defer' src="https://lionheart-education.com/wp-content/plugins/gravityforms/assets/js/dist/utils.min.js?ver=48a3755090e76a154853db28fc254681" id="gform_gravityforms_utils-js"></script>
<script type="text/javascript" defer='defer' src="https://lionheart-education.com/wp-content/plugins/gravityforms/assets/js/dist/vendor-theme.min.js?ver=4f8b3915c1c1e1a6800825abd64b03cb" id="gform_gravityforms_theme_vendors-js"></script>
<script type="text/javascript" id="gform_gravityforms_theme-js-extra">
/* <![CDATA[ */
var gform_theme_config = {"common":{"form":{"honeypot":{"version_hash":"049c7236a7e56ca64076ab4f4695a3db"},"ajax":{"ajaxurl":"https://lionheart-education.com/wp-admin/admin-ajax.php","ajax_submission_nonce":"1dc3c73322","i18n":{"step_announcement":"Step %1$s of %2$s, %3$s","unknown_error":"There was an unknown error processing your request. Please try again."}}}},"hmr_dev":"","public_path":"https://lionheart-education.com/wp-content/plugins/gravityforms/assets/js/dist/","config_nonce":"6e346aed50"};
//# sourceURL=gform_gravityforms_theme-js-extra
/* ]]> */
</script>
<script type="text/javascript" defer='defer' src="https://lionheart-education.com/wp-content/plugins/gravityforms/assets/js/dist/scripts-theme.min.js?ver=0183eae4c8a5f424290fa0c1616e522c" id="gform_gravityforms_theme-js"></script>
<script type="text/javascript">
/* <![CDATA[ */
 gform.initializeOnLoaded( function() { jQuery(document).on('gform_post_render', function(event, formId, currentPage){if(formId == 3) {} } );jQuery(document).on('gform_post_conditional_logic', function(event, formId, fields, isInit){} ) } ); 
/* ]]> */
</script>
<script type="text/javascript">
/* <![CDATA[ */
 gform.initializeOnLoaded( function() {jQuery(document).trigger("gform_pre_post_render", [{ formId: "3", currentPage: "1", abort: function() { this.preventDefault(); } }]);        if (event && event.defaultPrevented) {                return;        }        const gformWrapperDiv = document.getElementById( "gform_wrapper_3" );        if ( gformWrapperDiv ) {            const visibilitySpan = document.createElement( "span" );            visibilitySpan.id = "gform_visibility_test_3";            gformWrapperDiv.insertAdjacentElement( "afterend", visibilitySpan );        }        const visibilityTestDiv = document.getElementById( "gform_visibility_test_3" );        let postRenderFired = false;        function triggerPostRender() {            if ( postRenderFired ) {                return;            }            postRenderFired = true;            gform.core.triggerPostRenderEvents( 3, 1 );            if ( visibilityTestDiv ) {                visibilityTestDiv.parentNode.removeChild( visibilityTestDiv );            }        }        function debounce( func, wait, immediate ) {            var timeout;            return function() {                var context = this, args = arguments;                var later = function() {                    timeout = null;                    if ( !immediate ) func.apply( context, args );                };                var callNow = immediate && !timeout;                clearTimeout( timeout );                timeout = setTimeout( later, wait );                if ( callNow ) func.apply( context, args );            };        }        const debouncedTriggerPostRender = debounce( function() {            triggerPostRender();        }, 200 );        if ( visibilityTestDiv && visibilityTestDiv.offsetParent === null ) {            const observer = new MutationObserver( ( mutations ) => {                mutations.forEach( ( mutation ) => {                    if ( mutation.type === 'attributes' && visibilityTestDiv.offsetParent !== null ) {                        debouncedTriggerPostRender();                        observer.disconnect();                    }                });            });            observer.observe( document.body, {                attributes: true,                childList: false,                subtree: true,                attributeFilter: [ 'style', 'class' ],            });        } else {            triggerPostRender();        }    } ); 
/* ]]> */
</script>

                    <script id="perfmatters-delayed-scripts-js">(function(){window.pmDC=1;window.pmDT=15;if(window.pmDT){var e=setTimeout(d,window.pmDT*1e3)}const t=["keydown","mousedown","mousemove","wheel","touchmove","touchstart","touchend"];const n={normal:[],defer:[],async:[]};const o=[];const i=[];var r=false;var a="";window.pmIsClickPending=false;t.forEach(function(e){window.addEventListener(e,d,{passive:true})});if(window.pmDC){window.addEventListener("touchstart",b,{passive:true});window.addEventListener("mousedown",b)}function d(){if(typeof e!=="undefined"){clearTimeout(e)}t.forEach(function(e){window.removeEventListener(e,d,{passive:true})});if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",s)}else{s()}}async function s(){c();u();f();m();await w(n.normal);await w(n.defer);await w(n.async);await p();document.querySelectorAll("link[data-pmdelayedstyle]").forEach(function(e){e.setAttribute("href",e.getAttribute("data-pmdelayedstyle"))});window.dispatchEvent(new Event("perfmatters-allScriptsLoaded")),E().then(()=>{h()})}function c(){let o={};function e(t,e){function n(e){return o[t].delayedEvents.indexOf(e)>=0?"perfmatters-"+e:e}if(!o[t]){o[t]={originalFunctions:{add:t.addEventListener,remove:t.removeEventListener},delayedEvents:[]};t.addEventListener=function(){arguments[0]=n(arguments[0]);o[t].originalFunctions.add.apply(t,arguments)};t.removeEventListener=function(){arguments[0]=n(arguments[0]);o[t].originalFunctions.remove.apply(t,arguments)}}o[t].delayedEvents.push(e)}function t(t,n){const e=t[n];Object.defineProperty(t,n,{get:!e?function(){}:e,set:function(e){t["perfmatters"+n]=e}})}e(document,"DOMContentLoaded");e(window,"DOMContentLoaded");e(window,"load");e(document,"readystatechange");t(document,"onreadystatechange");t(window,"onload")}function u(){let n=window.jQuery;Object.defineProperty(window,"jQuery",{get(){return n},set(t){if(t&&t.fn&&!o.includes(t)){t.fn.ready=t.fn.init.prototype.ready=function(e){if(r){e.bind(document)(t)}else{document.addEventListener("perfmatters-DOMContentLoaded",function(){e.bind(document)(t)})}};const e=t.fn.on;t.fn.on=t.fn.init.prototype.on=function(){if(this[0]===window){function t(e){e=e.split(" ");e=e.map(function(e){if(e==="load"||e.indexOf("load.")===0){return"perfmatters-jquery-load"}else{return e}});e=e.join(" ");return e}if(typeof arguments[0]=="string"||arguments[0]instanceof String){arguments[0]=t(arguments[0])}else if(typeof arguments[0]=="object"){Object.keys(arguments[0]).forEach(function(e){delete Object.assign(arguments[0],{[t(e)]:arguments[0][e]})[e]})}}return e.apply(this,arguments),this};o.push(t)}n=t}})}function f(){document.querySelectorAll("script[type=pmdelayedscript]").forEach(function(e){if(e.hasAttribute("src")){if(e.hasAttribute("defer")&&e.defer!==false){n.defer.push(e)}else if(e.hasAttribute("async")&&e.async!==false){n.async.push(e)}else{n.normal.push(e)}}else{n.normal.push(e)}})}function m(){var o=document.createDocumentFragment();[...n.normal,...n.defer,...n.async].forEach(function(e){var t=e.getAttribute("src");if(t){var n=document.createElement("link");n.href=t;if(e.getAttribute("data-perfmatters-type")=="module"){n.rel="modulepreload"}else{n.rel="preload";n.as="script"}o.appendChild(n)}});document.head.appendChild(o)}async function w(e){var t=e.shift();if(t){await l(t);return w(e)}return Promise.resolve()}async function l(t){await v();return new Promise(function(e){const n=document.createElement("script");[...t.attributes].forEach(function(e){let t=e.nodeName;if(t!=="type"){if(t==="data-perfmatters-type"){t="type"}n.setAttribute(t,e.nodeValue)}});if(t.hasAttribute("src")){n.addEventListener("load",e);n.addEventListener("error",e)}else{n.text=t.text;e()}t.parentNode.replaceChild(n,t)})}async function p(){r=true;await v();document.dispatchEvent(new Event("perfmatters-DOMContentLoaded"));await v();window.dispatchEvent(new Event("perfmatters-DOMContentLoaded"));await v();document.dispatchEvent(new Event("perfmatters-readystatechange"));await v();if(document.perfmattersonreadystatechange){document.perfmattersonreadystatechange()}await v();window.dispatchEvent(new Event("perfmatters-load"));await v();if(window.perfmattersonload){window.perfmattersonload()}await v();o.forEach(function(e){e(window).trigger("perfmatters-jquery-load")})}async function v(){return new Promise(function(e){requestAnimationFrame(e)})}function h(){window.removeEventListener("touchstart",b,{passive:true});window.removeEventListener("mousedown",b);i.forEach(e=>{if(e.target.outerHTML===a){e.target.dispatchEvent(new MouseEvent("click",{view:e.view,bubbles:true,cancelable:true}))}})}function E(){return new Promise(e=>{window.pmIsClickPending?g=e:e()})}function y(){window.pmIsClickPending=true}function g(){window.pmIsClickPending=false}function L(e){e.target.removeEventListener("click",L);C(e.target,"pm-onclick","onclick");i.push(e),e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();g()}function b(e){if(e.target.tagName!=="HTML"){if(!a){a=e.target.outerHTML}window.addEventListener("touchend",A);window.addEventListener("mouseup",A);window.addEventListener("touchmove",k,{passive:true});window.addEventListener("mousemove",k);e.target.addEventListener("click",L);C(e.target,"onclick","pm-onclick");y()}}function k(e){window.removeEventListener("touchend",A);window.removeEventListener("mouseup",A);window.removeEventListener("touchmove",k,{passive:true});window.removeEventListener("mousemove",k);e.target.removeEventListener("click",L);C(e.target,"pm-onclick","onclick");g()}function A(e){window.removeEventListener("touchend",A);window.removeEventListener("mouseup",A);window.removeEventListener("touchmove",k,{passive:true});window.removeEventListener("mousemove",k)}function C(e,t,n){if(e.hasAttribute&&e.hasAttribute(t)){event.target.setAttribute(n,event.target.getAttribute(t));event.target.removeAttribute(t)}}})();</script><script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'9cd5990f79d6b35b',t:'MTc3MDk5OTA0Ny4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>
</html>
